import os
import argparse

logo = r"""
                                  .___    __                                                                              
_____  ___  ___ _____ _____     __| _/   |__| ____   ____     ___________  ___  ______  ______________  _______  __ ____  
\__  \ \  \/  //     \\__  \   / __ |    |  |/  _ \ /    \   / ____/\__  \ \  \/  /\  \/  /  _ \_  __ \/  _ \  \/ // ___\ 
 / __ \_>    <|  Y Y  \/ __ \_/ /_/ |    |  (  <_> )   |  \ < <_|  | / __ \_>    <  >    <  <_> )  | \(  <_> )   /\  \___ 
(____  /__/\_ \__|_|  (____  /\____ |/\__|  |\____/|___|  /  \__   |(____  /__/\_ \/__/\_ \____/|__|   \____/ \_/  \___  >
     \/      \/     \/     \/      \/\______|           \/      |__|     \/      \/      \/                            \/ 
"""

def show_structure(path, indent=0):
    folders = []
    files = []

    for item in os.listdir(path):
        full_path = os.path.join(path, item)
        if os.path.isdir(full_path):
            folders.append(item)
        else:
            files.append(item)

    for folder in folders:
        print("    " * indent + f"📁 {folder}/")
        show_structure(os.path.join(path, folder), indent + 1)

    for file in files:
        print("    " * indent + f"📄 {file}")

    if indent == 0:
        print("---------")

def main():
    parser = argparse.ArgumentParser(
        description="📂 FLS (Folder Listing System) - Display all folders and files from the current directory recursively."
    )

    parser.add_argument(
        "--path", "-p",
        type=str,
        default=os.getcwd(),
        help="The path to start scanning from. Defaults to the current working directory."
    )

    parser.add_argument(
        "--creator", "-c",
        action="store_true",
        help="Show the tool creator info and exit."
    )

    args = parser.parse_args()

    if args.creator:
        print(logo)
        print("👨‍💻 Created by: Axmadjon Qaxxorov")
        print("🛠 Command name: Folder View System(fvs)")
        print("🔗 taplink: https://taplink.cc/qaxxorovc\n")
        return

    root_path = os.path.expanduser(args.path)
    print(f"\n📍 Started from: {root_path}\n")
    show_structure(root_path)

if __name__ == "__main__":
    main()
